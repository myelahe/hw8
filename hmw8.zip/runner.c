# include <stdio.h>
# include <stdlib.h>

struct time 
{
    int min;//elhebabaei 402 23 007
    int sec;
};

struct runner
{
    char first_name [25];
    char last_name [25];
    int ID;
    struct time *record;
    struct time runnig_time;
};

int main ()
{
    int number,i,value ,N;
    value=0;

    printf("pleae enter number of participents\n");
    scanf("%d",&number);

    struct runner participent [number];

    for(i=0;i<number;i++)
    {
        printf("please enter name of participent\n");
        scanf("%s %s",&participent[i].first_name,&participent[i].last_name);
    
        printf("please enter id\n");
        scanf("%d",&participent[i].ID);
    
        participent[i].record=(struct time *)malloc(sizeof(struct time));
        printf("please enter record \tmin\tsec\n");
        scanf ("%d %d",&participent[i].record->min,&participent[i].record->sec);

        printf("please enter time \tmin\tsec\n");
        scanf ("%d %d",&participent[i].runnig_time.min,&participent[i].runnig_time.sec);
        
    } 

   struct runner winner=participent[0]; ;

   for(i=1;i<number;i++)
   {
       if(participent[i].runnig_time.min > winner.runnig_time.min)
           winner=participent[i];
        else if(participent[i].runnig_time.min==winner.runnig_time.min)
           if(participent[i].runnig_time.sec > winner.runnig_time.sec)
               winner=participent[i];
   }
     
   printf("winner is %s %s\n",winner.first_name,winner.last_name);

   if ((winner.record->min)>(winner.runnig_time.min))
       printf("he(she) can break him(her)record\n");
   else if((winner.record->min)<(winner.runnig_time.min))
       printf("he(she) can not break him(her)record\n");
   else  
   {
       if ((winner.record->sec)>(winner.runnig_time.sec))
          printf("he(she) can break him(her)record\n");
        else
           printf("he(she) can not break him(her)record\n");
   }

    for(i=0;i<number;i++)
        if ((winner.record->min)<(participent[i].record->min));
          value++;
    if(value==number)
       printf("he(she) can break every partcipent's record\n");
    else
        printf("he(she) can break every partcipent's record\n");

    printf("runnig time ,naame ,id ,record");
    printf("\n%d:%d\t%s\t%s\t%d\t%d:%d\n",winner.runnig_time.min,winner.runnig_time.sec,winner.first_name,winner.last_name,winner.ID,winner.record->min,winner.record->sec);
    N=number;
    struct runner compair[N];
    while(N)
    {
        for (i=0;i<N;i++)
        {
           if(participent[i].runnig_time.min>winner.runnig_time.min)
              compair[i]=participent[i];
           else if(participent[i].runnig_time.min==winner.runnig_time.min)
              if(participent[i].runnig_time.min>winner.runnig_time.min)       
                compair[i]=participent[i];
        }
        N--;
        for(i=0;i<N;i++)
        {
            if(compair[i].runnig_time.min > winner.runnig_time.min)
                winner=compair[i];
            else if(compair[i].runnig_time.min==winner.runnig_time.min)
                if(compair[i].runnig_time.sec > winner.runnig_time.sec)
                    winner=compair[i];
        }
        for (i=0;i<N;i++)
            if(winner.runnig_time.min!=compair[i].runnig_time.min)
                 if(winner.runnig_time.sec!=compair[i].runnig_time.sec)
                      participent[i]= compair[i];  
         printf("%d:%d\t%s\t%s\t%d\t%d:%d\n",winner.runnig_time.min,winner.runnig_time.sec,winner.first_name,winner.last_name,winner.ID,winner.record->min,winner.record->sec);
    
    }

    for(i=0;i<number;i++)
       free( participent[i].record);
}